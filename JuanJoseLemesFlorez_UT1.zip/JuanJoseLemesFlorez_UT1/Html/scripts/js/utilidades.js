
// Fichero con mis funciones de java scripts

function leerFicheroXML () {
    if (window.XMLHttpRequest)
    {
        // Objeto para IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
    }else{
        // Objeto para IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
    
    // Abrimos el archivo que esta alojado en el servidor cd_catalog.xml
    xmlhttp.open("GET","usuarios.xml",false);
    xmlhttp.send();
    
    // Obtenemos un objeto XMLDocument con el contenido del archivo xml del servidor
    xmlDoc=xmlhttp.responseXML;
    
    // Obtenemos todos los nodos denominados foro del archivo xml
    var foros=xmlDoc.getElementsByTagName("foro");
    
    // Hacemos un bucle por todos los elementos foro
    for(var i=0;i<foros.length;i++)
    {
        // Del elemento foro, obtenemos del primer elemento denominado "titulo"
        // el valor del primer elemento interno
        titulo=foros[i].getElementsByTagName("titulo")[0].childNodes[0].nodeValue
    
        url=foros[i].getElementsByTagName("url")[0].childNodes[0].nodeValue
    
        document.write("<div>");
            document.write("<span>");
            document.write(titulo);
            document.write("</span><span>");
            document.write("<a href='"+url+"' target='_blank'>"+url+"</a>");
            document.write("</span>");
        document.write("</div>");
    }
}

// Funciones de control de coockies
// ********************************

function setCookie(cname, cvalue, exdays) { // parametro: nombre de la coockie, calor de la cookie, dias de expiración)
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires="+ d.toUTCString();
    document.cookie = cname + "=" + cvalue + "; " + expires;
}


function checkCookie(cname) {
    var cookieName=getCookie(cname);
    if (cookieName!="") {
        alert("Welcome again " + cookieName);
        return true;
    } else {
       /* cookieName = prompt("Please enter your name:", "");
        if (cookieName != "" && cookieName != null) {
            setCookie("username", cookieName,1);
        ;    
        }*/
        ;
    }
}


function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i <ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length,c.length);
        }
    }
    return "";
}


