//libreria codigo dbasicos

function validar()  {

    window.open("../index.html", "_self");
    alert("vuelvo");

}


//crear coockie




function validarUsuario(usuario,pwd){   //Devuelve true coincide usuario y pasword
    alert("Buscado: "+usuario+"-"+pwd);

    if (window.XMLHttpRequest)
    {
        // Objeto para IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
    }else{
        // Objeto para IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
    
    // Abrimos el archivo que esta alojado en el servidor usuarios.xml
    xmlhttp.open("GET","../../../XML/usuarios.xml",false);
    xmlhttp.send();
    
    // Obtenemos un objeto XMLDocument con el contenido del archivo xml del servidor
    xmlDoc=xmlhttp.responseXML;
    
    // Obtenemos todos los nodos denominados foro del archivo xml
    var usuarios=xmlDoc.getElementsByTagName("usuario");
    var encontrado=false;
    // Hacemos un bucle por todos los elementos fichero usuarios si alguno coincide con los parametros recibidos devolvemos un True si no, False.
    alert("longitud del fichero -->"+usuarios.length);
    for(var i=0;i<usuarios.length;i++)
    {
        // Del elemento users, obtenemos del primer elemento denominado "usuario"
        // el valor del primer elemento interno
        var user= usuarios[i].getElementsByTagName("user")[0].childNodes[0].nodeValue;
    
        var pass=usuarios[i].getElementsByTagName("pwd")[0].childNodes[0].nodeValue;
        alert("en fichero:  "+user+"--->"+pass);
        if(user == usuario && pass == pwd){
            console.log("aqui llega ");
            alert("usuarios encontrado: "+ user+" - "+pass);
            encontrado=true;
            
           // $('#usuarioLogeado').html(usuario);
           // $('#btn_logout').show();
           // $('#Primerbtn').hide();  
           // $('#div_validacion').hide();
            setCookie('username_Asir', $('#correo').val(), 1); 
          //  $('#perfil').show();

            break;
        }

      /*  document.write("<div>");
            document.write("<span>");
            document.write(titulo);
            document.write("</span><span>");
            document.write("<a href='"+url+"' target='_blank'>"+url+"</a>");
            document.write("</span>");
        document.write("</div>");*/
    }

    if (!encontrado){
        alert("Usuario o password incorrectos, pruebe de nuevo..");
    } 
			return encontrado;
	

}